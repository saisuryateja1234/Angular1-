import { ScrollPipe } from './scroll.pipe';

describe('ScrollPipe', () => {
  it('create an instance', () => {
    const pipe = new ScrollPipe();
    expect(pipe).toBeTruthy();
  });
});
